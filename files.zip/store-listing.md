# Sakeenah — Play Store Listing

## App name (max 30 characters)
Sakeenah

## Short description (max 80 characters)
A verse and a saying of the Prophet ﷺ for whatever's on your heart today.

## Full description (max 4000 characters)

Sakeenah (سكينة) means stillness — a sense of calm that settles the heart.

This app gives you a quiet place to put into words what you're carrying, and
in return offers a matched verse from the Qur'an and an authentic hadith
from Sahih al-Bukhari or Sahih Muslim — both in Arabic and English.

HOW IT WORKS
Type how you're feeling, or speak it using voice input. Sakeenah listens
for the feeling behind your words — anxious, sad, grieving, lonely, angry,
afraid, tired, grateful, and more — and brings you a verse and hadith that
speaks to it. Or simply tap one of the quick feeling buttons for an
instant response.

WHAT'S INSIDE
• The complete Qur'an (all 114 chapters, Arabic + English), bundled
  directly into the app
• A curated selection of authentic hadiths from Sahih al-Bukhari and
  Sahih Muslim, each with its exact reference so you can verify it yourself
• Fully bilingual interface — English and Arabic throughout
• Voice input, so you can speak instead of type
• A "Generate image" feature — turn your verse and hadith into a shareable
  image you can save and send to family or friends
• A print option, for displaying a verse and hadith somewhere in your home

PRIVACY FIRST
Sakeenah works completely offline. Nothing you type or say is ever sent
anywhere, stored on a server, or shared with anyone. Your reflections stay
on your device, and only your device.

Whether you're going through a hard day, sitting with grief, feeling
anxious about something ahead, or simply want a moment of stillness,
Sakeenah is here — quietly, privately, and always available.

## Category
Lifestyle (or: Books & Reference)

## Tags / keywords
quran, hadith, islam, muslim, dua, dhikr, sakeenah, islamic reminder,
mental health, mindfulness, prayer, sahih bukhari, sahih muslim

## Content rating questionnaire notes
- No violence, no user-generated content shared with others, no ads,
  no in-app purchases, no data collection.
- Should qualify for the lowest content rating tier (e.g. "Everyone" / PEGI 3).

## Contact email
[YOUR EMAIL HERE — required field in Play Console]

## Privacy policy URL
[INSERT THE HOSTED URL OF privacy-policy.md/.html ONCE LIVE]
