# Sakeenah — Path to Play Store: What's Ready & What's Left

## What I've prepared for you

1. **`twa-manifest.json`** — the Bubblewrap configuration that generates
   your Android app wrapper. Has placeholder text wherever your real
   domain/URL needs to go.
2. **`manifest.json`** — the web app manifest that needs to sit in the
   same folder as your `sakeenah.html` file once hosted.
3. **`store-listing.md`** — your app's title, descriptions, category,
   and tags, ready to copy-paste into Play Console.
4. **`privacy-policy.html`** — a complete, ready-to-host privacy policy
   page (Sakeenah collects zero data, so this is short and simple).
   Just upload this file alongside your app and it'll work as-is — only
   the date and your contact email need filling in.
5. **`icon-192.png`, `icon-512.png`, `icon-maskable-512.png`** — the
   three required app icons, designed around the same geometric star
   motif and sage/clay palette as the app itself. Ready to use exactly
   as they are.

## What you still need to do, in order

### Step 1 — Host the app (free)
Pick one:
- **GitHub Pages** (free, simple): create a GitHub account, create a new
  repository, upload `sakeenah.html` (renamed to `index.html`), plus
  `manifest.json`, `privacy-policy.html`, and the 3 icon PNGs — all in
  the same folder. Turn on Pages in repo settings. You'll get a URL like
  `https://yourname.github.io/sakeenah/`.
- **Netlify** or **Vercel** (also free): drag-and-drop the same files,
  get a URL like `https://sakeenah.netlify.app`.

Once hosted, your privacy policy will be live at something like
`https://yourname.github.io/sakeenah/privacy-policy.html` — that's the
exact URL you'll paste into Play Console later. Before going live,
open that file and fill in the date and your contact email.

### Step 2 — Fill in the placeholders
In `twa-manifest.json`, replace every `REPLACE-WITH-YOUR-DOMAIN.com` with
your actual hosted URL from Step 1.

### Step 3 — Run Bubblewrap
This step needs to happen on your own computer (it needs Java/Android
SDK installed, which I can't run here). The commands are:

```
npm install -g @bubblewrap/cli
bubblewrap init --manifest=https://your-hosted-url.com/manifest.json
bubblewrap build
```

This generates a signed `.aab` file — the actual Android app package.
Bubblewrap will prompt you to create a signing key during this process;
**save that key file somewhere safe** — you'll need the exact same one
for every future update of the app.

### Step 4 — Google Play Developer account
- Go to https://play.google.com/console
- Pay the one-time $25 registration fee
- Verify your identity (Google may ask for ID/business details)

### Step 5 — Submit
- Create a new app in Play Console
- Upload the `.aab` file from Step 4
- Paste in the text from `store-listing.md`
- Paste in your hosted privacy policy URL from Step 1
- Fill in the content rating questionnaire (notes are in `store-listing.md`)
- Submit for review (usually takes a few days to a couple of weeks)

## Where I can help further, right now
- Walk through the GitHub Pages hosting steps in detail when you're ready
- Update `twa-manifest.json` once you have your real hosted URL
- Adjust the icon designs if you'd like a different look
